import { createAsyncThunk, createSlice, useDispatch } from '@reduxjs/toolkit';

const initialState = {
  entities: [],
  loading: 'idle'
}

// const url = 'https://my-json-server.typicode.com/akscipy/test-json-server/items';
// const url = 'https://18nf7homec.execute-api.eu-central-1.amazonaws.com/data/pricetoema/50/100';
const url = 'https://18nf7homec.execute-api.eu-central-1.amazonaws.com/data/ema2price';

const getDynamicUrl = (params) => {
  // let dynamicUrl = null;
  const emaVal = params.length1;

  // const urlReadyPairsArr = [ 5, 7, 8, 9, 10, 12, 13, 20, 21, 25, 26, 30, 34, 40, 45, 50, 55, 80, 89, 100, 140, 144, 200, 233, 314, 360, 377, 610, 987 ];

  // if (urlReadyPairsArr.includes(params.malength1)) {
  //   dynamicUrl = `${url}/${tmpArr[0]}/${tmpArr[1]}`;
  // } else {
  //   dynamicUrl = ``;
  // }

  const dynamicUrl = `${url}/${emaVal}`;
  // console.log(dynamicUrl);

  return dynamicUrl;
}


const pricetoemaHelpers = {
  dataMapper: (dataArr) => {
    const dataObjArr = dataArr.map((item, index) => {
      // console.log(item);
      const tmpObj = {
        id: index,
        WatchList: { inWatchList: true },
        Pair: {
          name: item[0],
          imgPath: '/images/eth.png',
          inWatchList: true,
        },
        M15: item[1],
        H1: item[2],
        H4: item[3],
        H12: item[4],
        D: item[5],
        W: item[6],
        Price: item[7],
        _24Hr: item[8],
        Volume: item[9],
        Chart: {
          imagePath: '/images/tv_logo_2.png',
          url: 'https://in.tradingview.com/chart/'
        },
        Filter: {
          name: 'Trade',
          url: 'https://in.tradingview.com/chart/'
        }
      };
      // console.log(tmpObj);
      return tmpObj;
    })
    return dataObjArr;
  }
}

// export const getPricetoemaAsync = createAsyncThunk('posts/getPricetoemaAsync', async (params={}, thunkAPI) => fetch(url).then((res) => res.json()));

export const getPricetoemaAsync = createAsyncThunk('posts/getPricetoemaAsync', async (params={data}, thunkAPI) => {
  let dynamicUrl = getDynamicUrl(params);
  const x0 = await fetch(dynamicUrl).then((res) => res.json());
  return x0;
});

export const pricetoemaAsyncSlice = createSlice({
  name: 'pricetoemaAsync',
  initialState,
  reducers: {},
  extraReducers: {
    [getPricetoemaAsync.pending]: (state, action) => {
      state.status = 'loading';
    },
    [getPricetoemaAsync.fulfilled]: (state, { payload }) => {
      const x0 = pricetoemaHelpers.dataMapper(payload);
      // console.log(x0);
      // state.entities = payload;
      state.entities = x0;
      state.status = 'success';
    },
    [getPricetoemaAsync.rejected]: (state, action) => {
      state.status = 'failed';
    },
  }
})

export default pricetoemaAsyncSlice.reducer
