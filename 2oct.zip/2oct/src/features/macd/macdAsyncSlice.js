import { createAsyncThunk, createSlice, useDispatch } from '@reduxjs/toolkit';

const initialState = {
  entities: [],
  loading: 'idle'
}

// const url = 'https://my-json-server.typicode.com/akscipy/test-json-server/items';
const url = 'https://18nf7homec.execute-api.eu-central-1.amazonaws.com/data/macd';

const macdHelpers = {
  dataMapper: (dataArr) => {
    // console.log(dataArr);
    const dataObjArr = dataArr.map((item, index) => {
      // console.log(item);
      const tmpObj = {
        id: index,
        WatchList: { inWatchList: true },
        Pair: {
          name: item[0],
          imgPath: '/images/eth.png',
          inWatchList: true,
        },
        M15: item[1],
        H1: item[2],
        H4: item[3],
        H12: item[4],
        D: item[5],
        W: item[6],
        Price: item[7],
        _24Hr: item[8],
        Volume: item[9],
        Chart: {
          // imagePath: '/images/tv_logo_2.jpg',
          imagePath: '/images/tv_logo_2.png',
          // imagePath: '/images/eth.png',
          url: 'https://in.tradingview.com/chart/'
        },
        Filter: {
          name: 'Trade',
          url: 'https://in.tradingview.com/chart/'
        }
      };
      // console.log(tmpObj);
      return tmpObj;
      // { id: 1, WatchList: { inWatchList: true }, Pair: { name: 'BTCUSD', imgPath: '/images/eth.png', inWatchList: true }, M15: 99, H1: '23', H4: 35,
      // H12: 16, D: '55', W: '23', Price: "$35", _24Hr: 1, Volume: '4.3M',
      // Chart: { imagePath: '/images/tv_logo_2.png', url: 'https://in.tradingview.com/chart/' }, Filter: {name: 'Trade', url: 'https://in.tradingview.com/chart/'} },
    })
    return dataObjArr;
  }
}

export const getMacdAsync = createAsyncThunk('posts/getMacdAsync', async (params={}, thunkAPI) => fetch(url).then((res) => res.json()));

export const macdAsyncSlice = createSlice({
  name: 'macdAsync',
  initialState,
  reducers: {},
  extraReducers: {
    [getMacdAsync.pending]: (state, action) => {
      state.status = 'loading';
    },
    [getMacdAsync.fulfilled]: (state, { payload }) => {
      const x0 = macdHelpers.dataMapper(payload);
      // console.log(x0);
      // state.entities = payload;
      state.entities = x0;
      state.status = 'success';
    },
    [getMacdAsync.rejected]: (state, action) => {
      state.status = 'failed';
    },
  }
})

export default macdAsyncSlice.reducer
