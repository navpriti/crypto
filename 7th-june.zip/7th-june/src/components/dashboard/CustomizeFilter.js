import * as React from 'react';
import { Box, Button, Typography, Paper, Grid, Radio, RadioGroup, FormControlLabel} from '@mui/material';
import { styled } from '@mui/material/styles';
import PairMenu from '@/src/components/dashboard/pair-menu';
import Exchange from '@/src/components/dashboard/exchange';
import Timeframe from '@/src/components/dashboard/Timeframe';
import LaggingFull from '@/src/components/dashboard/LaggingFull';
import Stochasticfilter from '@/src/components/dashboard/Stochasticfilter';
import FsrFilter from './FsrFilter';
import RsiFilter from './RsiFilter';
import LeadingfullFilter from './Leadingfullfilter';
import LaggingfullFilter from './Laggingfullfilter';
import Volumefilter from './Volumefilter';
import Hourch from './24hrfilter';
import Marketcapfilter from './Marketcapfilter';
import PricemovingAverageFilter from './PricemovingFilter';
import MovingAverageFilter from './MovingFilter';
import FilterAltIcon from '@mui/icons-material/FilterAlt';

  
export default function HorizontalLinearStepper() {
  return (
    <Box>
        <Grid item xs={6} md={12} sx={{ textAlign:'end',padding:'20px 20px 0px 0px'}}>
            <Button variant="contained"><FilterAltIcon />Reset Filter</Button>
        </Grid>
    <Paper>
    <Grid container spacing={2} sx={{ mt:2, mb: 3}}>
        <Grid item xs={6} md={3}>
         <Exchange />
        </Grid>
        <Grid item xs={6} md={3}>
          <PairMenu />
        </Grid>
        <Grid item xs={6} md={3}>
          <Timeframe />
        </Grid>
        <Grid item xs={6} md={3}>
         <LaggingFull />
        </Grid>
      </Grid>

      <Grid container spacing={2} sx={{ mt:2, mb: 3}}>
        <Grid item xs={6} md={3}>
         <FsrFilter />
        </Grid>
        <Grid item xs={6} md={3}>
          <RsiFilter />
        </Grid>
        <Grid item xs={6} md={3}>
          <LeadingfullFilter />
        </Grid>
        <Grid item xs={6} md={3}>
         <LaggingfullFilter />
        </Grid>
      </Grid>

      <Grid container spacing={2}  sx={{ mt:2, mb: 3}}>
        <Grid item xs={6} md={3}>
         <Volumefilter />
        </Grid>
        <Grid item xs={6} md={3}>
          <Marketcapfilter />
        </Grid>
        <Grid item xs={6} md={3}>
          <Hourch />
        </Grid>
        <Grid item xs={6} md={3}>
        <Stochasticfilter/>
        </Grid>
      </Grid>


      <Grid container spacing={2} sx={{ mt:2, mb: 3}}>
        <Grid item xs={6} md={12}>
         <PricemovingAverageFilter />
        </Grid>
      </Grid>
      <Grid container spacing={2} sx={{ mt:2, mb: 3}}>
        <Grid item xs={6} md={12}>
         <MovingAverageFilter />
        </Grid>
      </Grid>
    </Paper>
    <Grid item xs={6} md={12} sx={{ display:'flex',padding:'20px', justifyContent:'end'}}>
    <RadioGroup
        row
        aria-labelledby="demo-row-radio-buttons-group-label"
        name="row-radio-buttons-group"
      >
        <FormControlLabel value="Above" control={<Radio />} label="Remember me" />
      </RadioGroup> 
            <Button variant="contained"><FilterAltIcon />Apply Filter</Button>
        </Grid>
  </Box>
  );
}
