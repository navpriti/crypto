import { createAsyncThunk, createSlice, useDispatch } from '@reduxjs/toolkit';

const initialState = {
  entities: [],
  loading: 'idle'
}

// const url = 'https://my-json-server.typicode.com/akscipy/test-json-server/items';
// const url = 'https://18nf7homec.execute-api.eu-central-1.amazonaws.com/data/emacross/50/100';
const url = 'https://18nf7homec.execute-api.eu-central-1.amazonaws.com/data/emacross';

const getDynamicUrl = (params) => {
  let dynamicUrl = null;
  const tmpArr = params.malength1.split('*');

  const urlReadyPairsArr = [
    '5*10',
    '8*21',
    '8*34',
    '10*20',
    '20*50',
    '21*55',
    '50*100',
    '50*200',
  ];

  if (urlReadyPairsArr.includes(params.malength1)) {
    dynamicUrl = `${url}/${tmpArr[0]}/${tmpArr[1]}`;
  } else {
    dynamicUrl = ``;
  }

  return dynamicUrl;
}


const emacrossHelpers = {
  dataMapper: (dataArr) => {
    const dataObjArr = dataArr.map((item, index) => {
      // console.log(item);
      const tmpObj = {
        id: index,
        WatchList: { inWatchList: true },
        Pair: {
          name: item[0],
          imgPath: '/images/eth.png',
          inWatchList: true,
        },
        M15: item[1],
        H1: item[2],
        H4: item[3],
        H12: item[4],
        D: item[5],
        W: item[6],
        Price: item[7],
        _24Hr: item[8],
        Volume: item[9],
        Chart: {
          // imagePath: '/images/tv_logo_2.png',
          imagePath: '/images/chart.png',
          url: 'https://in.tradingview.com/chart/'
        },
        Filter: {
          name: 'Trade',
          url: 'https://in.tradingview.com/chart/'
        }
      };
      // console.log(tmpObj);
      return tmpObj;
    })
    return dataObjArr;
  }
}

// export const getEmacrossAsync = createAsyncThunk('posts/getEmacrossAsync', async (params={}, thunkAPI) => fetch(url).then((res) => res.json()));

export const getEmacrossAsync = createAsyncThunk('posts/getEmacrossAsync', async (params={data}, thunkAPI) => {
  let dynamicUrl = getDynamicUrl(params);
  const x0 = await fetch(dynamicUrl).then((res) => res.json());
  return x0;
});

export const emacrossAsyncSlice = createSlice({
  name: 'emacrossAsync',
  initialState,
  reducers: {},
  extraReducers: {
    [getEmacrossAsync.pending]: (state, action) => {
      state.status = 'loading';
    },
    [getEmacrossAsync.fulfilled]: (state, { payload }) => {
      const x0 = emacrossHelpers.dataMapper(payload);
      // console.log(x0);
      // state.entities = payload;
      state.entities = x0;
      state.status = 'success';
    },
    [getEmacrossAsync.rejected]: (state, action) => {
      state.status = 'failed';
    },
  }
})

export default emacrossAsyncSlice.reducer
