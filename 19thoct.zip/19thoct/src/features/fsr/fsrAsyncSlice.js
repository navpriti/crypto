import { createAsyncThunk, createSlice, useDispatch } from '@reduxjs/toolkit';

const initialState = {
  entities: [],
  loading: 'idle'
}

// const url = 'https://my-json-server.typicode.com/akscipy/test-json-server/items';
const url = 'https://18nf7homec.execute-api.eu-central-1.amazonaws.com/data/fsr';

const fsrHelpers = {
  dataMapper: (dataArr) => {
    // console.log(dataArr);
    const dataObjArr = dataArr.map((item, index) => {
      // console.log(item);
      const tmpObj = {
        id: index,
        WatchList: { inWatchList: true },
        Pair: {
          name: item[0],
          imgPath: '/images/eth.png',
          inWatchList: true,
        },
        M15: item[1] ? item[1].toFixed(0) : null,
        H1: item[2] ? item[2].toFixed(0) : null,
        H4: item[3] ? item[3].toFixed(0) : null,
        H12: item[4] ? item[4].toFixed(0) : null,
        D: item[5] ? item[5].toFixed(0) : null,
        W: item[6] ? item[6].toFixed(0) : null,
        Price: item[7],
        _24Hr: item[8],
        Volume: item[9],
        Chart: {
          // imagePath: '/images/tv_logo_2.png',
          imagePath: '/images/chart.png',
          url: 'https://in.tradingview.com/chart/'
        },
        Filter: {
          name: 'Trade',
          url: 'https://in.tradingview.com/chart/'
        }
      };
      // console.log(tmpObj);
      return tmpObj;
    })
    return dataObjArr;
  }
}

export const getFsrAsync = createAsyncThunk('posts/getFsrAsync', async (params={}, thunkAPI) => fetch(url).then((res) => res.json()));

export const fsrAsyncSlice = createSlice({
  name: 'fsrAsync',
  initialState,
  reducers: {},
  extraReducers: {
    [getFsrAsync.pending]: (state, action) => {
      state.status = 'loading';
    },
    [getFsrAsync.fulfilled]: (state, { payload }) => {
      const x0 = fsrHelpers.dataMapper(payload);
      // console.log(x0);
      // state.entities = payload;
      state.entities = x0;
      state.status = 'success';
    },
    [getFsrAsync.rejected]: (state, action) => {
      state.status = 'failed';
    },
  }
})

export default fsrAsyncSlice.reducer
