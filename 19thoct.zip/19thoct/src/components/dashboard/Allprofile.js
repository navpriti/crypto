import * as React from 'react';
import { styled } from '@mui/material/styles';
import Card from '@mui/material/Card';
import CardHeader from '@mui/material/CardHeader';
import CardMedia from '@mui/material/CardMedia';
import CardContent from '@mui/material/CardContent';
import CardActions from '@mui/material/CardActions';
import Collapse from '@mui/material/Collapse';
import Avatar from '@mui/material/Avatar';
import IconButton from '@mui/material/IconButton';
import Typography from '@mui/material/Typography';
import { red } from '@mui/material/colors';
import FavoriteIcon from '@mui/icons-material/Favorite';
import ShareIcon from '@mui/icons-material/Share';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faBtc } from '@fortawesome/free-brands-svg-icons';
import StarRate from '@mui/icons-material/StarRate';
import { InsertLink } from '@mui/icons-material';
import { makeStyles } from '@mui/styles';
import { Button } from '@mui/material';
import { Info } from '@mui/icons-material';
import ToggleButton from '@mui/material/ToggleButton';
import ToggleButtonGroup from '@mui/material/ToggleButtonGroup';


const StyledToggleButton = styled(ToggleButton)`
  border-radius: 50%;
  border: none;
  &.Mui-selected {
    color: yellow;
    background:transparent
    /**/
  }
`;
const StyledFavouriteToggleButton = styled(ToggleButton)`
  border-radius: 50%;
  border: none;
  &.Mui-selected {
    color: red;
    background:transparent
    /**/
  }
`;

const useStyles = makeStyles({
    card: {
      width: 320,
      boxShadow: "0 5px 8px 0 rgba(0, 0, 0, 0.3)",
      backgroundColor: "#042b4b",
    },
    avatar:{width:"60px",height:"60px", backgroundColor: "#ffffff",fontSize: "35px"},
    cardheader:{fontSize:"10px"},
    cardSection:{display:"flex"},
    cardtitle:{marginTop:"24px"},
    cardheading:{fontSize:"20px"},
    cardSubheading:{fontSize:"14px"},
    heading:{paddingBottom:"10px",borderBottom:"1px solid #fff", fontSize:"18px"},
    subheading:{paddingTop:"10px", fontSize:"14px"},
    media: {
      height: 300,
    },
    likecount: {
      position: "absolute",top: "-6px", left: "21px", zIndex: "21",background: "#90caf9",
      padding: "5px", borderRadius: "50%",fontSize: "12px",color:"#000", fontWeight:"600"
  }
  });

export default function Allprofile() {
  const [alignment, setAlignment] = React.useState('');

  const handleAlignment = (event, newAlignment) => {
    setAlignment(newAlignment);
  };
    const classes = useStyles();
  return (
    <Card className={classes.card}>
      <div className={classes.cardSection}>
      <CardHeader className={classes.cardheader}
        avatar={
          <Avatar sx={{ bgcolor: red[500],fontSize:"30px" }} aria-label="recipe"  className={classes.avatar}>
             <FontAwesomeIcon icon={faBtc} />
          </Avatar>
        }>
        </CardHeader>
        <div className={classes.cardtitle}>
        <Typography variant="h3" color="text.secondary"className={classes.cardheading}>
         Mr.Andreson
        </Typography>
        <Typography variant="p" color="text.secondary"className={classes.cardSubheading}>
         @truecrypto28
        </Typography>
          </div> 
          </div>       
      <CardContent sx={{textAlign:"center"}}>
        <Typography variant="h4" color="text.secondary" className={classes.heading}>
         Stretegy !
        </Typography>
        <Typography variant="h5" color="text.secondary"className={classes.subheading}>
         Moving Average Cross
        </Typography>
      </CardContent>
      <CardActions sx={{justifyContent: "space-around"}}>
      <IconButton aria-label="rating">
            <InsertLink sx={{fontSize:"25px"}} />
        </IconButton>
        <ToggleButtonGroup
      value={alignment}
      exclusive
      onChange={handleAlignment}
      aria-label="text alignment"
    >
      <StyledToggleButton value="left" aria-label="left aligned">
      <StarRate  sx={{fontSize:"25px"}}/>
      </StyledToggleButton>
    </ToggleButtonGroup>
        <IconButton aria-label="share">
          <ShareIcon  sx={{fontSize:"25px"}}/>
        </IconButton>
        <ToggleButtonGroup
      value={alignment}
      exclusive
      onChange={handleAlignment}
      aria-label="text alignment"
    >
      <StyledFavouriteToggleButton value="left" aria-label="left aligned">
      <FavoriteIcon  sx={{fontSize:"25px"}}/>
          <div className={classes.likecount}>10</div>
      </StyledFavouriteToggleButton>
    </ToggleButtonGroup>
      </CardActions>
      <CardActions sx={{justifyContent: "space-evenly",background: "#203144",padding:"5px", marginTop:"20px"}}>
          <Button sx={{fontSize:"13px",background: "#203144",width:"100%", borderRadius:"0px"}}><Info sx={{fontSize: "16px",marginRight: "6px"}}/> Details</Button>
          <Button sx={{fontSize:"13px",background: "#203144",borderLeft: "1px solid #fff",marginRight: "0px",width: "100%", 
          borderRadius:"0px"}}>Apply Scan</Button>
      </CardActions>
    </Card>
  );
}
