import * as React from 'react';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormControl from '@mui/material/FormControl';
import { styled } from '@mui/material/styles';
import TextField from '@mui/material/TextField';
import ToggleButton from '@mui/material/ToggleButton';
import ToggleButtonGroup from '@mui/material/ToggleButtonGroup';


const FormLabel = styled(FormControl)(({ theme }) => ({
  textAlign: 'center',
  position: 'relative',
  top: '-10px',
  background: '#132235',
  width: 'max-content',
  padding: '0px 16px',
}));

export default function RsiFilter() {
  const [alignment, setAlignment] = React.useState('web');

  const handleChange = (event, newAlignment) => {
    setAlignment(newAlignment);
  };
  return (
    <FormControl style={{
      width:"96%",
      padding: ' 0px 10px 10px 10px',
      border: '1px solid #595555',
      borderRadius: '6px', margin: '0px 7px',
    }}>
      <FormLabel id="demo-row-radio-buttons-group-label">Price Change</FormLabel>
      <RadioGroup
        row
        aria-labelledby="demo-row-radio-buttons-group-label"
        name="row-radio-buttons-group"
      >
       <p style={{margin:"10px 16px"}}>From</p>
        <TextField id="demo-helper-text-misaligned-no-helper" label="Value" />
        <p style={{margin:"10px 10px 0px 30px"}}>To</p>
        <TextField id="demo-helper-text-misaligned-no-helper" label="Value" />
      </RadioGroup>
      <ToggleButtonGroup
      color="primary"
      value={alignment}
      exclusive
      onChange={handleChange}
      aria-label="Platform"
      style={{marginTop:"20px",marginLeft:"16px", display:"flex" , justifyContent:"center"}}
    >
      <ToggleButton value="-50%">-50%</ToggleButton>
      <ToggleButton value="-50% 50 -10%">-50% to -10%</ToggleButton>
      <ToggleButton value="-10% to 0">-10% to 0</ToggleButton>
      <ToggleButton value="0% to 10%">0% to 10%</ToggleButton>
      <ToggleButton value="10% to 50%">10% to 50%</ToggleButton>
      <ToggleButton value="50%">50%</ToggleButton>
    </ToggleButtonGroup>

    </FormControl>
  );
}
