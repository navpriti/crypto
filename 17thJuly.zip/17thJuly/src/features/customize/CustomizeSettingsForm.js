// Customized forms

import React from 'react'
import PropTypes from 'prop-types'

const CustomizeSettingsForm = (props) => {
  return (
    <div />
  )
}

export default CustomizeSettingsForm
