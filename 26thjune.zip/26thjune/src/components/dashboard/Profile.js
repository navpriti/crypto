import * as React from 'react';
import { Box, Button, Typography, Paper, Grid, Radio, RadioGroup, FormControlLabel} from '@mui/material';
import { styled,alpha } from '@mui/material/styles';
import InputBase from '@mui/material/InputBase';
import SearchIcon from '@mui/icons-material/Search';
import Timeframe from '@/src/components/dashboard/Timeframe';
import BasicTabs from './ProfileTab';
import ButtonGroup from '@mui/material/ButtonGroup';
import Allprofile from './Allprofile';



const Search = styled('div')(({ theme }) => ({
    position: 'relative',
    borderRadius: theme.shape.borderRadius,
    backgroundColor: alpha(theme.palette.common.white, 0.15),
    '&:hover': {
      backgroundColor: alpha(theme.palette.common.white, 0.25),
    },
    marginLeft: 0,
    width: '100%',
    [theme.breakpoints.up('sm')]: {
      marginLeft: theme.spacing(1),
      width: 'auto',
      marginTop: "9px",
    },
  }));
  
  const SearchIconWrapper = styled('div')(({ theme }) => ({
    padding: theme.spacing(0, 2),
    height: '100%',
    position: 'absolute',
    pointerEvents: 'none',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  }));
  
  const StyledInputBase = styled(InputBase)(({ theme }) => ({
    color: 'inherit',
    '& .MuiInputBase-input': {
      padding: theme.spacing(1, 1, 1, 0),
      // vertical padding + font size from searchIcon
      paddingLeft: `calc(1em + ${theme.spacing(4)})`,
      transition: theme.transitions.create('width'),
      width: '100%',
      [theme.breakpoints.up('sm')]: {
        width: '12ch',
        '&:focus': {
          width: '20ch',
        },
      },
    },
  }));
  
export default function Profile() {
  return (
    <Box>
    <Paper>
    <Grid container spacing={2} sx={{ mt:1, mb: 3}}>
        <Grid item xs={6} md={3}>
        <Search>
            <SearchIconWrapper>
              <SearchIcon />
            </SearchIconWrapper>
            <StyledInputBase
              placeholder="Search…"
              inputProps={{ 'aria-label': 'search' }}
            />
          </Search>
        </Grid>
        <Grid item xs={6} md={6} sx={{    marginTop: "8px",textAlign: "center"}}>
        <ButtonGroup variant="contained" aria-label="outlined primary button group" size="large" sx={{width:"55%"}}>
      <Button sx={{width:"100%"}}>All Profiles</Button>
      <Button sx={{width:"100%"}}>Favourite</Button>
    </ButtonGroup>
        </Grid>
        <Grid item xs={6} md={3}>
          <Timeframe />
        </Grid>
      </Grid>
      <Grid container spacing={2} sx={{ mt:2, mb: 3}}>
        <Grid item xs={6} md={12}>
        <Grid container spacing={2} sx={{ mt:2, mb: 3}}>
        <Grid item xs={6} md={3}>
        <Allprofile />
            </Grid>
            <Grid item xs={6} md={3}>
        <Allprofile />
            </Grid>
            <Grid item xs={6} md={3}>
        <Allprofile />
            </Grid>
            <Grid item xs={6} md={3}>
        <Allprofile />
            </Grid>
        </Grid>

        </Grid>
      </Grid>
    </Paper>
  </Box>
  );
}
