import { createSlice } from '@reduxjs/toolkit'

const initialState = {
  pairs: [
    {
      name: 'BTC',
      value: 'BTC'
    },
    {
      name: 'USDT',
      value: 'USDT'
    },
    {
      name: 'USD',
      value: 'USD'
    },
    {
      name: 'ALL',
      value: 'ALL'
    }
  ],
  exchanges: [
    {
      name: 'Binance',
      value: 'Binance',
    },
    {
      name: 'FTX',
      value: 'FTX',
    },

  ],
  timeframes: [
    {
      name: '1H',
      value: '1H',
    },
    {
      name: '4H',
      value: '4H',
    },
    {
      name: '12H',
      value: '12H',
    },
    {
      name: '1D',
      value: '1D',
    },
    {
      name: '4W',
      value: '4W',
    },
  ],
  laggingfulls: [
    {
      name: 'BULL',
      value: 'BULL'
    },
    {
      name: 'BEAR',
      value: 'BEAR'
    }
  ],
  stochastics: [
    {
      name: 'BULL',
      value: 'BULL'
    },
    {
      name: 'BEAR',
      value: 'BEAR'
    }
  ],
  trends: [
    {
      name: 'BULL',
      value: 'BULL'
    },
    {
      name: 'BEAR',
      value: 'BEAR'
    }
  ],
  macds: [
    {
      name: 'BULL',
      value: 'BULL'
    },
    {
      name: 'BEAR',
      value: 'BEAR'
    }
  ],
  sortby: [
    {
      name: 'Name',
      value: 'Name'
    },
    {
      name: 'Popularity',
      value: 'Popularity'
    }
  ],
  pair: 'BTC',
  exchange: 'Binance',
  timeframe:'1H',
  laggingfull:'BULL',
  stochastic:'BULL',
  trend:'BULL',
  macd:'BULL',
  sortBy:'Name'
}

export const standardSlice = createSlice({
  name: 'standard',
  initialState,
  reducers: {
    setPair: (state, { payload }) => {
      state.pair = payload
    },
    setExchange: (state, { payload }) => {
      state.exchange = payload
    },
    setTimeframe:(state, { payload }) => {
      state.timeframe = payload
    },
    setLaggingFull:(state, { payload }) => {
      state.laggingfull = payload
    },
    setStochastic:(state, { payload }) => {
      state.stochastic = payload
    },
    setTrend:(state, { payload }) => {
      state.trend = payload
    },
    setMacd:(state, { payload }) => {
      state.macd = payload
    },
    setSortBy:(state, {payload}) =>{
      state.sortBy = payload
    }
  },
})

// Action creators are generated for each case reducer function
export const { setPair, setExchange, setTimeframe, setLaggingFull, setSortBy, setStochastic, setTrend, setMacd} = standardSlice.actions

export default standardSlice.reducer
