import { configureStore } from '@reduxjs/toolkit'
// import counterReducer from '../features/counter/counterSlice'
import counterReducer from '@/src/features/counter/counterSlice'
import postsReducer from '@/src/features/posts/postsSlice'
import topBullCoinsReducer from '@/src/features/top-bull-coins/topBullCoinsSlice'
import topBullCoinsAsyncReducer from '@/src/features/top-bull-coins/topBullCoinsAsyncSlice'
import trendingCoinsAsyncReducer from '@/src/features/trending-coins/trendingCoinsAsyncSlice'
import selectedMainTabReducer from '@/src/features/selected-main-tab/selectedMainTabSlice'
import priceToMaIndicatorReducer from '@/src/features/standard/priceToMaIndicatorSlice'
import standardReducer from '@/src/features/standard/standardSlice'
import mainHomeButtonReducer from '@/src/features/mainHomeButtonSlice'
import macdAsyncReducer from '@/src/features/macd/macdAsyncSlice'
import rsiAsyncReducer from '@/src/features/rsi/rsiAsyncSlice'
import emacrossAsyncReducer from '@/src/features/emacross/emacrossAsyncSlice'
import pricetoemaAsyncReducer from '@/src/features/pricetoema/pricetoemaAsyncSlice'
import fsrAsyncReducer from '@/src/features/fsr/fsrAsyncSlice'
import laggingfullAsyncReducer from '@/src/features/laggingfull/laggingfullAsyncSlice'
import leadingfullAsyncReducer from '@/src/features/leadingfull/leadingfullAsyncSlice'


// console.log(counterReducer);

const store = configureStore({
  reducer: {
    counter: counterReducer,
    posts: postsReducer,
    topBullCoins: topBullCoinsReducer,
    topBullCoinsAsync: topBullCoinsAsyncReducer,
    macdAsync: macdAsyncReducer,
    rsiAsync: rsiAsyncReducer,
    emacrossAsync: emacrossAsyncReducer,
    pricetoemaAsync: pricetoemaAsyncReducer,
    fsrAsync: fsrAsyncReducer,
    laggingfullAsync: laggingfullAsyncReducer,
    leadingfullAsync: leadingfullAsyncReducer,
    trendingCoinsAsync: trendingCoinsAsyncReducer,
    selectedMainTab: selectedMainTabReducer,
    priceToMaIndicator: priceToMaIndicatorReducer,
    standard: standardReducer,
    mainHomeButton: mainHomeButtonReducer,
  },
})

export default store;
