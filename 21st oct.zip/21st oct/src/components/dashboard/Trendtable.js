// import * as React from 'react';
import React, {useEffect} from 'react';
import { useSelector, useDispatch } from 'react-redux';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Box';
import Paper from '@mui/material/Box';
import Button from '@mui/material/Button';
import Link from '@mui/material/Link';
import IconButton from '@mui/material/IconButton';
import { DataGrid } from '@mui/x-data-grid';
import ArrowDropUpIcon from '@mui/icons-material/ArrowDropUp';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import Avatar from '@mui/material/Avatar';
import Stack from '@mui/material/Stack';
import StarPurple500Icon from '@mui/icons-material/StarPurple500';
import StarRateIcon from '@mui/icons-material/StarRate';
import DeleteIcon from '@mui/icons-material/Delete';
import SvgIcon from '@mui/material/SvgIcon';
import FilterListIcon from '@mui/icons-material/FilterList';

import { getMacdAsync } from '@/src/features/macd/macdAsyncSlice';
import { getRsiAsync } from '@/src/features/rsi/rsiAsyncSlice';
import { getEmacrossAsync } from '@/src/features/emacross/emacrossAsyncSlice';
import { getPricetoemaAsync } from '@/src/features/pricetoema/pricetoemaAsyncSlice';
// import { getFsrAsync } from '@/src/features/fsr/fsrAsyncSlice';
// import { getLaggingfullAsync } from '@/src/features/laggingfull/laggingfullAsyncSlice';
// import { getLeadingfullAsync } from '@/src/features/leadingfull/leadingfullAsyncSlice';


const columns = [
  { field: 'WatchList',
    headerName: '.',
    sortable: false,
    width: 50,
    headerClassName:'tableheader',
    align: 'center',
    headerAlign: 'center',
    renderCell: (params) => {
      return (
        <>
          {!params.value.inWatchList ? (<StarPurple500Icon color="none" sx={{ cursor: 'pointer' }} />) : (<StarRateIcon color="warning" sx={{ cursor: 'pointer' }} />)}
        </>
      );
    }},
  { field: 'Pair', headerName: 'Pair', minWidth: 180, headerAlign: 'left',
    headerClassName: 'tableheader',
    renderCell: (params) => {
      return (
        <>
          <Avatar src={params.value.imgPath}
            sx={{ width: 21, height: 21, mr: 1 }}
          />
          <Typography>
            {params.value.name}
          </Typography>
        </>
      );
    }},
  // { field: 'Pair', headerName: 'Pair', width: 90,headerClassName:'tableheader'},
  { field: 'M15', headerName: 'M15', minWidth: 50, headerClassName:'tableheader', align: 'center', headerAlign: 'center', flex: 1,
    renderCell: (params) => {
      // console.log(params.row.M15);
      return (
        <>
          {params.row.M15 == 1 ? (
            <ArrowDropUpIcon fontSize="large" style={{ color: "green" }} />
          ) : (
            <ArrowDropDownIcon fontSize="large" style={{ color: "red" }} />
          )}
        </>
      );
    }
  },
  { field: 'H1', headerName: 'H1', minWidth: 50,headerClassName:'tableheader',  align: 'center', headerAlign: 'center', flex: 1,
    renderCell: (params) => {
      // console.log(params.row.M15);
      return (
        <>
          {params.row.H1 == 1 ? (
            <ArrowDropUpIcon fontSize="large" style={{ color: "green" }} />
          ) : (
            <ArrowDropDownIcon fontSize="large" style={{ color: "red" }} />
          )}
        </>
      );
    }
  },
  { field: 'H4', headerName: 'H4', minWidth: 50, headerClassName:'tableheader',  align: 'center', headerAlign: 'center', flex: 1,
    renderCell: (params) => {
      // console.log(params.row.M15);
      return (
        <>
          {params.row.H4 == 1 ? (
            <ArrowDropUpIcon fontSize="large" style={{ color: "green" }} />
          ) : (
            <ArrowDropDownIcon fontSize="large" style={{ color: "red" }} />
          )}
        </>
      );
    }
  },
  { field: 'H12', headerName: 'H12', minWidth: 50,headerClassName:'tableheader',  align: 'center', headerAlign: 'center', flex: 1,
    renderCell: (params) => {
      // console.log(params.row.M15);
      return (
        <>
          {params.row.H12 == 1 ? (
            <ArrowDropUpIcon fontSize="large" style={{ color: "green" }} />
          ) : (
            <ArrowDropDownIcon fontSize="large" style={{ color: "red" }} />
          )}
        </>
      );
    }
  },
  { field: 'D', headerName: 'D', minWidth: 50,headerClassName:'tableheader',  align: 'center', headerAlign: 'center', flex: 1,
    renderCell: (params) => {
      // console.log(params.row.M15);
      return (
        <>
          {params.row.D == 1 ? (
            <ArrowDropUpIcon fontSize="large" style={{ color: "green" }} />
          ) : (
            <ArrowDropDownIcon fontSize="large" style={{ color: "red" }} />
          )}
        </>
      );
    }
  },
  { field: 'W', headerName: 'W', minWidth: 50,headerClassName:'tableheader',  align: 'center', headerAlign: 'center', flex: 1,
    renderCell: (params) => {
      // console.log(params.row.M15);
      return (
        <>
          {params.row.W == 1 ? (
            <ArrowDropUpIcon fontSize="large" style={{ color: "green" }} />
          ) : (
            <ArrowDropDownIcon fontSize="large" style={{ color: "red" }} />
          )}
        </>
      );
    }
  },
  { field: 'Price', headerName: 'Price', minWidth: 110,headerClassName:'tableheader',  align: 'center', headerAlign: 'center', flex: 1},
  { field: '_24Hr', headerName: '%24Hr', minWidth: 110,headerClassName:'tableheader',  align: 'center', headerAlign: 'center', flex: 1},
  { field: 'Volume', headerName: 'Volume', minWidth: 110,headerClassName:'tableheader', align: 'center', headerAlign: 'center', flex: 1},

  { field: 'Chart', headerName: 'Chart', minWidth: 110, headerAlign: 'center',
    headerClassName: 'tableheader', flex: 1, sortable: false, align: 'center',
    renderCell: (params) => {
      return (
        <>
          <a href={params.value.url} target="_blank">
            <Avatar src={params.value.imagePath}
              sx={{ width: 42, height: 42, mr: 1 }}
            />
          </a>
         </>
      );
    }},


    { field: 'Filter', headerName: '.', minWidth: 110, headerAlign: 'center',color:'#000',
      headerClassName: 'tableheader', flex: 1, sortable: false, align: 'center',
      renderCell: (params) => {
        return (
          <>
            <Link color="inherit" underline="none" href={params.value.url} target="_blank">
              <Button variant="outlined" size="small">
                Trade
              </Button>
            </Link>
           </>
        );
      }},
  // { field: 'Filter', headerName: 'Filter', width: 120,headerClassName:'tableheader', headerClassName:'tableheader', align: 'center', headerAlign: 'center', flex: 1, sortable: false},
];


const rows = [
  { id: 1, WatchList: { inWatchList: true }, Pair: { name: 'BTCUSD', imgPath: '/images/eth.png', inWatchList: true }, M15: { imagePath: '/images/green.png'}, H1: { imagePath: '/images/green.png'}, H4: { imagePath: '/images/green.png'}, H12: { imagePath: '/images/green.png'}, D: { imagePath: '/images/red.png'}, W: { imagePath: '/images/red.png'}, Price: "$35", _24Hr: 1, Volume: '4.3M', Chart: { imagePath: '/images/chart.png', url: 'https://in.tradingview.com/chart/' }, Filter: {name: 'Trade', url: 'https://in.tradingview.com/chart/'} },
  { id: 2, WatchList: { inWatchList: false }, Pair: { name: 'ADAUSD', imgPath: '/images/eth.png', inWatchList: false }, M15: { imagePath: '/images/green.png'}, H1: { imagePath: '/images/green.png'}, H4: { imagePath: '/images/green.png'}, H12: { imagePath: '/images/green.png'}, D: { imagePath: '/images/red.png'}, W: { imagePath: '/images/red.png'}, Price: "$35", _24Hr: -10, Volume: '4.3M', Chart: { imagePath: '/images/chart.png', url: 'https://in.tradingview.com/chart/' }, Filter: {name: 'Trade', url: 'https://in.tradingview.com/chart/'} },
  { id: 3, WatchList: { inWatchList: false }, Pair: { name: 'XRPUSD', imgPath: '/images/eth.png', inWatchList: false }, M15: { imagePath: '/images/green.png'}, H1: { imagePath: '/images/green.png'}, H4: { imagePath: '/images/green.png'}, H12: { imagePath: '/images/green.png'}, D: { imagePath: '/images/red.png'}, W: { imagePath: '/images/red.png'}, Price: "$35", _24Hr: 12, Volume: '4.3M', Chart: { imagePath: '/images/chart.png', url: 'https://in.tradingview.com/chart/' }, Filter: {name: 'Trade', url: 'https://in.tradingview.com/chart/'} },
  { id: 4, WatchList: { inWatchList: false }, Pair: { name: 'KNCUSD', imgPath: '/images/eth.png', inWatchList: true }, M15: { imagePath: '/images/green.png'}, H1: { imagePath: '/images/green.png'}, H4: { imagePath: '/images/green.png'}, H12: { imagePath: '/images/green.png'}, D: { imagePath: '/images/red.png'}, W: { imagePath: '/images/red.png'}, Price: "$35", _24Hr: 0.06, Volume: '4.3M', Chart: { imagePath: '/images/chart.png', url: 'https://in.tradingview.com/chart/' }, Filter: {name: 'Trade', url: 'https://in.tradingview.com/chart/'} },
  { id: 5, WatchList: { inWatchList: true }, Pair: { name: 'SHIBUSDTPERP', imgPath: '/images/eth.png', inWatchList: false }, M15: { imagePath: '/images/green.png'}, H1: { imagePath: '/images/green.png'}, H4: { imagePath: '/images/green.png'}, H12: { imagePath: '/images/green.png'}, D: { imagePath: '/images/red.png'}, W: { imagePath: '/images/red.png'}, Price: "$35", _24Hr: 1.74, Volume: '4.3M', Chart: { imagePath: '/images/chart.png', url: 'https://in.tradingview.com/chart/' }, Filter: {name: 'Trade', url: 'https://in.tradingview.com/chart/'} },
];


// 'comfortable'
// | 'compact'
// | 'standard'

export default function ScannerDataTable() {
  const dispatch = useDispatch();

  const selectedMainTab = useSelector((state) => state.selectedMainTab);
  const selectedPriceToMaIndicator = useSelector((state) => state.priceToMaIndicator);
  const selectedPair = useSelector((state) => state.standard.pair);

  // console.log(selectedPriceToMaIndicator);

  useEffect (() => {
    dispatch(getMacdAsync());
    dispatch(getRsiAsync());
    dispatch(getEmacrossAsync(selectedPriceToMaIndicator));
  }, [dispatch]);

  useEffect (() => {
    dispatch(getEmacrossAsync(selectedPriceToMaIndicator));
    dispatch(getPricetoemaAsync(selectedPriceToMaIndicator));
  }, [selectedPriceToMaIndicator]);

  // useEffect (() => {
  //   dispatch(getPricetoemaAsync(selectedPriceToMaIndicator));
  // }, [selectedPriceToMaIndicator]);

  const macdRows = useSelector((state) => state.macdAsync.entities);
  const rsiRows = useSelector((state) => state.rsiAsync.entities);
  const emacrossAsyncRows = useSelector((state) => state.emacrossAsync.entities);
  const pricetoemaAsyncRows = useSelector((state) => state.pricetoemaAsync.entities);
  // const laggingfullRows = useSelector((state) => state.laggingfullAsync.entities);
  // const leadingfullRows = useSelector((state) => state.leadingfullAsync.entities);

  // console.log(selectedMainTab);
  // console.log(selectedPriceToMaIndicator.length2);

  // console.log(laggingfullRows);
  // console.log(selectedPair);

  let dataRows = null;
  if (selectedMainTab.value.toUpperCase() === 'MACD'.toUpperCase()) {
    // dataRows = macdRows;
    dataRows = selectedPair.toUpperCase() === 'All'.toUpperCase() ? macdRows : macdRows.filter(item => item.Pair.name.endsWith(selectedPair));
  } else if (selectedMainTab.value.toUpperCase() === 'RSI'.toUpperCase()) {
    // dataRows = rsiRows.filter(item => item.Pair.name.contains(selectedPair));
    dataRows = selectedPair.toUpperCase() === 'All'.toUpperCase() ? rsiRows : rsiRows.filter(item => item.Pair.name.endsWith(selectedPair));
  } else if (selectedMainTab.value.toUpperCase() === 'MA Cross'.toUpperCase()) {
    // dataRows = rsiRows.filter(item => item.Pair.name.contains(selectedPair));
    dataRows = selectedPair.toUpperCase() === 'All'.toUpperCase() ? emacrossAsyncRows : emacrossAsyncRows.filter(item => item.Pair.name.endsWith(selectedPair));
  } else if (selectedMainTab.value.toUpperCase() === 'Price To MA'.toUpperCase()) {
    // dataRows = rsiRows.filter(item => item.Pair.name.contains(selectedPair));
    dataRows = selectedPair.toUpperCase() === 'All'.toUpperCase() ? pricetoemaAsyncRows : pricetoemaAsyncRows.filter(item => item.Pair.name.endsWith(selectedPair));
  } else {
    dataRows = rows;
  }

  return (
    <Box
     sx={{
       height: 400,
       width: 1,
       '& .tableheader': { backgroundColor: '#182F4B' , fontWeight:600, fontSize:"12px"},
       '& .pair-header-cell': { backgroundColor: '##182F4B', pl: 4 },
       '& .watchlist-cell': { backgroundColor: '#182F4B', opacity: '100' }
     }}
   >

     {/*<DataGrid
       rows={rows}
       columns={columns}
       pageSize={5}
       rowsPerPageOptions={[5]}
       density="compact"
       disableColumnMenu={true}
     />*/}

     <DataGrid
       rows={dataRows}
       columns={columns}
       pageSize={100}
       rowsPerPageOptions={[20]}
       density="compact"
       disableColumnMenu={true}
     />
     </Box>
  );
}
