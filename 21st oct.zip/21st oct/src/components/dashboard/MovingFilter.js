import * as React from 'react';
import Box from '@mui/material/Box';
import { Button, Grid, FormControl ,Radio, FormControlLabel, TextField} from '@mui/material';
import { styled } from '@mui/material/styles';
import RadioGroup from '@mui/material/RadioGroup';
import Malength from "./malength";
import { useState } from 'react';

const FormLabel = styled(Box)(({ theme }) => ({
  textAlign: 'center',
  position: 'relative',
  top: '-19px',
  background: '#132235',
  width: 'max-content',
  padding: '0px 16px',
}));

const maxInputFields = 3;
const defaultNumberOfFields = 1;
export default function MovingAverageFilter() {
const [numberOfFields, setNumberOfFields] = useState(defaultNumberOfFields);


  function generateInputField() {
    return (
      <div style={{ paddingBottom: "10px" }}>
          <Box style={{width:'100%',padding: '10px',
    border: '1px solid #595555',
    borderRadius: '6px',margin: '0px 7px',}}>
        <Grid container>
        <Grid item xs={6} md={3}>
        <FormControl style={{width:'100%'}}>
      <FormLabel id="demo-row-radio-buttons-group-label">MA Cross</FormLabel>
      <RadioGroup
        row
        aria-labelledby="demo-row-radio-buttons-group-label"
        name="row-radio-buttons-group"
        style={{width:'100%', marginTop:"-10px", paddingLeft:"10px"}}
      >
        <FormControlLabel value="MA" control={<Radio />} label="MA" />
        <FormControlLabel value="EMA" control={<Radio />} label="EMA" />
      </RadioGroup> 
    </FormControl>
        </Grid>
        <Grid item xs={6} md={3}>
        <Malength />
        </Grid>
        <Grid item xs={6} md={3}>
        <FormControl>
      {/* <FormLabel id="demo-row-radio-buttons-group-label">Price to MA</FormLabel> */}
      <RadioGroup
        row
        aria-labelledby="demo-row-radio-buttons-group-label"
        name="row-radio-buttons-group"
        style={{width:'100%', marginTop:"6px",}}
      >
        <FormControlLabel value="Bull" control={<Radio />} label="Bull" />
        <FormControlLabel value="Bear" control={<Radio />} label="Bear" />
      </RadioGroup> 
    </FormControl>
        </Grid>
        <Grid item xs={6} md={3}>
        <p >Crossed</p>
        </Grid>
      </Grid>
    </Box>
      </div>
    );
  }



  function generateFields() {
    let listOfFields = [];
    for (let i = 1; i <= numberOfFields; i++) {
      listOfFields.push(generateInputField(i));
    }
    return listOfFields;
  }

  function handleButtonClick() {
    if (numberOfFields < maxInputFields) setNumberOfFields(numberOfFields + 1);
  }
  return (
    <div>
           {generateFields()}
        {numberOfFields < maxInputFields && (
            <Button variant="contained" onClick={handleButtonClick} className="add-filter">Add Filter</Button>
            )}
</div>
  );
}
