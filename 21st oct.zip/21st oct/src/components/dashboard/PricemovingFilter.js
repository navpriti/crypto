import * as React from 'react';
import Box from '@mui/material/Box';
import Slider from '@mui/material/Slider';
import { Button, Grid, FormControl ,Radio, FormControlLabel, TextField } from '@mui/material';
import PairMenu from '@/src/components/dashboard/pair-menu';
import { styled } from '@mui/material/styles';
import RadioGroup from '@mui/material/RadioGroup';
import SelectLength1 from '@/src/components/dashboard/select-length-1';
import { useState } from 'react';

const FormLabel = styled(Box)(({ theme }) => ({
  textAlign: 'center',
  position: 'relative',
  top: '-19px',
  background: '#132235',
  width: 'max-content',
  padding: '0px 16px',
}));

const maxInputFields = 3;
const defaultNumberOfFields = 1;


export default function PricemovingAverageFilter() {
  const [priceFilter, setPriceFilter] = useState(defaultNumberOfFields);

  function generateInputField() {
    return (
      <div style={{ paddingBottom: "10px" }}>
          <Box style={{width:'100%',padding: '10px',
    border: '1px solid #595555',
    borderRadius: '6px',margin: '0px 7px',}}>
        <Grid container>
        <Grid item xs={6} md={3}>
        <FormControl style={{width:'100%'}}>
      <FormLabel id="demo-row-radio-buttons-group-label">Price to MA</FormLabel>
      <RadioGroup
        row
        aria-labelledby="demo-row-radio-buttons-group-label"
        name="row-radio-buttons-group"
        style={{width:'100%', marginTop:"-10px", paddingLeft:"10px"}}
      >
        <FormControlLabel value="MA" control={<Radio />} label="MA" />
        <FormControlLabel value="EMA" control={<Radio />} label="EMA" />
      </RadioGroup> 
    </FormControl>
        </Grid>
        <Grid item xs={6} md={3}>
        <SelectLength1 />
        </Grid>
        <Grid item xs={6} md={3}>
        <FormControl>
      {/* <FormLabel id="demo-row-radio-buttons-group-label">Price to MA</FormLabel> */}
      <RadioGroup
        row
        aria-labelledby="demo-row-radio-buttons-group-label"
        name="row-radio-buttons-group"
        style={{width:'100%', marginTop:"6px",}}
      >
        <FormControlLabel value="Above" control={<Radio />} label="Above" />
        <FormControlLabel value="Below" control={<Radio />} label="Below" />
      </RadioGroup> 
    </FormControl>
        </Grid>
        <Grid item xs={6} md={3}>
        <p>Value</p>
        </Grid>
      </Grid>
    </Box>
      </div>
    );
  }



  function generateFields() {
    let listOfFields = [];
    for (let i = 1; i <= priceFilter; i++) {
      listOfFields.push(generateInputField(i));
    }
    return listOfFields;
  }

  function handleButtonClick() {
    if (priceFilter < maxInputFields) setPriceFilter(priceFilter + 1);
  }





  return (
    <div>
    {generateFields()}
 {priceFilter < maxInputFields && (
     <Button variant="contained" onClick={handleButtonClick} className="add-filter">Add Filter</Button>
     )}
</div>
  );
}
