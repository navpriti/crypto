import * as React from 'react';
import { useSelector, useDispatch } from 'react-redux'
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Grid from '@mui/material/Grid';
import Divider from '@mui/material/Divider';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import IconButton from '@mui/material/IconButton';
import Paper from '@mui/material/Paper';
import { Dashboard, Settings, Person, } from '@mui/icons-material';
import { Info } from '@mui/icons-material';
import RadarOutlinedIcon from '@mui/icons-material/RadarOutlined';
import PairMenu from '@/src/components/dashboard/pair-menu';
import Exchange from '@/src/components/dashboard/exchange';
import MainTabs from '@/src/components/dashboard/main-tabs';
import SelectMA from '@/src/components/dashboard/select-ma-type';
import SelectLength1 from '@/src/components/dashboard/select-length-1';
import SelectLength2 from '@/src/components/dashboard/select-length-2';
import Tooltip from '@mui/material/Tooltip';
import Profile from './Profile';
import Scannertable from './Scannertable';
import ScannerDataTable from './Trendtable';
import { setMainHomeButton } from '@/src/features/mainHomeButtonSlice';
import { selectedMainTab } from '@/src/features/selected-main-tab/selectedMainTabSlice';
import DownloadIcon from '@mui/icons-material/Download';
import ShareIcon from '@mui/icons-material/Share';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import MenuIcon from '@mui/icons-material/Menu';
import { styled, alpha } from '@mui/material/styles';
import InputBase from '@mui/material/InputBase';
import SearchIcon from '@mui/icons-material/Search';
import CustomizeFilter from './CustomizeFilter';
import FilterListIcon from '@mui/icons-material/FilterList';
import LaggingFull from '@/src/components/dashboard/LaggingFull';
import { useTheme, } from '@mui/material/styles';
import Malength from "./malength";
import { useRef, useLayoutEffect } from 'react'


const StyledTooltip = styled(({ className, ...props }) => (
  <Tooltip {...props} classes={{ popper: className }} />
))(({ theme }) => ({
  zIndex: theme.zIndex.tooltip + 1,
  //margin: 4,
  [`& .MuiTooltip-tooltip`]: {
    backgroundColor:"#42a5f5",
    margin: 4,
    padding: 8,
    whiteSpace: "pre-line"
    //border: "solid yellow 1px"
  }
}));
const soManyWords =
  "I have a lot of good things to say about MUI!\n \
   It's the greatest thing since sliced bread Super!";
const tooltipTop = {
  "& .MuiTooltip-tooltip": {
    border: "solid #42a5f5 1px",
    color: "#000",
    fontSize:"11px",
    fontWeight:600,
    textAlign:"center"
  }
};


const Search = styled('div')(({ theme }) => ({
  position: 'relative',
  borderRadius: theme.shape.borderRadius,
  backgroundColor: alpha(theme.palette.common.white, 0.15),
  '&:hover': {
    backgroundColor: alpha(theme.palette.common.white, 0.25),
  },
  marginLeft: 0,
  width: '100%',
  [theme.breakpoints.up('sm')]: {
    marginLeft: theme.spacing(1),
    width: 'auto',
  },
}));

const SearchIconWrapper = styled('div')(({ theme }) => ({
  padding: theme.spacing(0, 2),
  height: '100%',
  position: 'absolute',
  pointerEvents: 'none',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
}));

const StyledInputBase = styled(InputBase)(({ theme }) => ({
  color: 'inherit',
  '& .MuiInputBase-input': {
    padding: theme.spacing(1, 1, 1, 0),
    // vertical padding + font size from searchIcon
    paddingLeft: `calc(1em + ${theme.spacing(4)})`,
    transition: theme.transitions.create('width'),
    width: '100%',
    [theme.breakpoints.up('sm')]: {
      width: '12ch',
      '&:focus': {
        width: '20ch',
      },
    },
  },
}));




function IndicatorSettings({ selectedMainTab }) {
  if (selectedMainTab.toUpperCase() === 'Trend'.toUpperCase()) {
    return (
      <Paper>
        <Box sx={{border: 0, pl: 1, textAlign: 'left',background:"#132235",marginTop:"-18px"}}>
          <ScannerDataTable />
        </Box>
      </Paper>
    );
  }
  else if (selectedMainTab.toUpperCase() === 'Price To MA'.toUpperCase()) {
    return (
      <Paper>
        <Box sx={{border: 0, pl: 1, textAlign: 'left',background:"#132235",marginTop:"-18px"}}>
          <SelectMA />
          <SelectLength1 />
          <ScannerDataTable />
        </Box>
      </Paper>
    );
  } else if (selectedMainTab.toUpperCase() === 'MA Cross'.toUpperCase()) {
    return (
      <Paper>
        <Box sx={{border: 0, pl: 1, textAlign: 'left',background:"#132235",marginTop:"-18px"}}>
          <SelectMA />
          <Malength />
          <ScannerDataTable />
        </Box>
      </Paper>
    )
  }
  else if (selectedMainTab.toUpperCase() === 'RSI'.toUpperCase()) {
    return (
      <Paper>
        <Box sx={{border: 0, pl: 1, textAlign: 'left',background:"#132235",marginTop:"-18px"}}>
        <Scannertable />
        </Box>
      </Paper>
    )
  }
  else if (selectedMainTab.toUpperCase() === 'FSR'.toUpperCase()) {
    return (
      <Paper>
        <Box sx={{border: 0, pl: 1, textAlign: 'left',background:"#132235",marginTop:"-18px"}}>
        <SelectLength2/>
        <Scannertable />
        </Box>
      </Paper>
    )
  }
  else if (selectedMainTab.toUpperCase() === 'Stochastic'.toUpperCase()) {
    return (
      <Paper>
        <Box sx={{border: 0, pl: 1, textAlign: 'left',background:"#132235",marginTop:"-18px"}}>
          <Scannertable />
        </Box>
      </Paper>
    )
  }
  else if (selectedMainTab.toUpperCase() === 'MACD'.toUpperCase()) {
    return (
      <Paper>
        <Box sx={{border: 0, pl: 1, textAlign: 'left',background:"#132235",marginTop:"-18px"}}>
        <ScannerDataTable />
        </Box>
      </Paper>
    )
  }
  return <></>;
}

function HomeSteppersView({ selectedMainHomeButton }) {
  if (selectedMainHomeButton.value === 'Standard') {
    return (
      <Box sx={{p:2,m:1}} >
        <Grid container direction="row"  spacing={2} >
        {/* <Grid item xs={2} md={1} style={{display:'flex',alignItems:'center', height:'50px'}}>
        <Box sx={{border: 0, ml: 0}}>
          <Box component="span">
            <Typography variant="h5" component="overline">
            <RadarOutlinedIcon /> Scanner
            </Typography>
          </Box>
        </Box>
      </Grid> */}
          <Grid item xs={12} md={7}>
            <MainTabs />
          </Grid>
          <Grid item xs={3} md={2} sx={{ mt:1.2,}}>
          <Search>
            <SearchIconWrapper>
              <SearchIcon />
            </SearchIconWrapper>
            <StyledInputBase
              placeholder="Search…"
              inputProps={{ 'aria-label': 'search' }}
            />
          </Search>
              </Grid>
          <Grid item xs={12} md={3}>
            <Grid container direction="row">
              <Grid item xs={3} md={4}>
                <PairMenu />
              </Grid>
              <Grid item xs={3} md={4}>
                <Exchange />
              </Grid>
              <Grid item xs={2} md={4} style={{display:"flex",alignItems:"center"}}>
              <IconButton style={{width:"34px",height:"34px"}}><FilterListIcon /></IconButton>
                <IconButton style={{width:"34px",height:"34px"}}><DownloadIcon /></IconButton>
                <IconButton style={{width:"34px",height:"34px"}}><ShareIcon /></IconButton>
              </Grid>
            </Grid>

          </Grid>
        </Grid>
      </Box>
    );
  } else if (selectedMainHomeButton.value === 'Customize') {
    return (
      <Box sx={{border: 0, ml: 1, mt: 1}}>
        <Paper>
          <Grid>
          <CustomizeFilter />
          </Grid>
        </Paper>
      </Box>
    )
  } else if (selectedMainHomeButton.value === 'Profile') {
    return (
      <Box sx={{border: 0, ml: 1, mt: 1}}>
        <Paper>
          <Profile />
        </Paper>
      </Box>
    )
  }
  return <></>;
}


export default function IconTabs() {
  const theme = useTheme();
  const tHeadColor = (theme.palette.mode == 'dark') ? "#132235" : "white";
  const dispatch = useDispatch();
  const selectedMainHomeButton = useSelector((state) => state.mainHomeButton.selectedMainHomeButton);
  const selectedMainTab = useSelector((state) => state.selectedMainTab.value);
  const [value, setValue] = React.useState(0);

  // const handleChange = (event, newValue) => {
  //   setValue(newValue);
  // };

  // console.log(selectedMainTab);


  const stickyHeader = useRef()
  useLayoutEffect(() => {
    const mainHeader = document.getElementById('mainHeader')
    let fixedTop = stickyHeader.current.offsetTop
    const fixedHeader = () => {
      if (window.pageYOffset > fixedTop) {
        mainHeader.classList.add('fixedTop')
      } else {
        mainHeader.classList.remove('fixedTop')
      }
    }
    window.addEventListener('scroll', fixedHeader)
  }, [])

  return (
    <>
    <div className="mainHeader" id="mainHeader" ref={stickyHeader}>
    <Grid container direction="row" spacing={1}>    
      <Grid item xs={1}>
        <Box sx={{border: 0, ml: 0}}>
          <Box component="span">
            <Typography variant="h5" component="overline" sx={{display: 'flex',marginTop: '4px',marginLeft:'10px'}}>
            <RadarOutlinedIcon sx={{marginTop:'3px'}}/> Scanner
            </Typography>
          </Box>
        </Box>
      </Grid>
      <Grid item xs={11}>
        <Box sx={{border: 0, ml: 0}}>
          <Button variant={selectedMainHomeButton.value === 'Standard' ? 'contained' : 'outlined'} startIcon={<Dashboard />}  sx={{ marginRight: 2, marginLeft: 4, width: 124 }}
            onClick={() => dispatch(setMainHomeButton( {name: 'Standard', value: 'Standard'} ))}>Standard
            <StyledTooltip describeChild title="A measure of how much of cryptocurrency was traded in the last 24 hours" sx={tooltipTop}>
            <Info style={{marginLeft:"6px"}} />
           </StyledTooltip>
           </Button>
          <Button variant={selectedMainHomeButton.value === 'Customize' ? 'contained' : 'outlined'} startIcon={<Settings />} sx={{ marginRight: 2, width: 124 }}
            onClick={() => dispatch(setMainHomeButton( {name: 'Customize', value: 'Customize'} ))}>
            Customize
            <StyledTooltip describeChild title="A measure of how much of cryptocurrency was traded in the last 24 hours" sx={tooltipTop}>
            <Info style={{marginLeft:"6px"}}/>
           </StyledTooltip>
          </Button>
          <Button variant={selectedMainHomeButton.value === 'Profile' ? 'contained' : 'outlined'} startIcon={<Person />} sx={{ marginRight: 3, width: 124 }}
            onClick={() => dispatch(setMainHomeButton( {name: 'Profile', value: 'Profile'} ))}>
            Profile
            <StyledTooltip describeChild title="A measure of how much of cryptocurrency was traded in the last 24 hours" sx={tooltipTop}>
            <Info style={{marginLeft:"6px"}}/>
           </StyledTooltip>
          </Button>
        </Box>
      </Grid>
      </Grid>
      </div>

      <Grid container direction="row" spacing={1}>
      <Grid item xs={12}>
      <div className="main-block">
        <Grid container style={{ background: tHeadColor }}>
          <Grid item xs={12} style={{ background: tHeadColor }}>
            <Paper style={{ background: tHeadColor }}><HomeSteppersView selectedMainHomeButton={selectedMainHomeButton} style={{ background: tHeadColor }}/></Paper>
          </Grid>
          <Grid item xs={12}>
            <Paper style={{ background: tHeadColor }}>
              {selectedMainHomeButton.value === 'Standard' ? <IndicatorSettings selectedMainTab={selectedMainTab} /> : (<div></div>)}
            </Paper>
          </Grid>
          {/* <Grid item xs={12}>
            <Paper style={{ background: tHeadColor }}>
              {selectedMainHomeButton.value === 'Standard' ? (<Box><Scannertable /></Box>) : (<div></div>)}
            </Paper>
          </Grid> */}
        </Grid>
        </div>
      </Grid>
    </Grid>
</>
  );
}
