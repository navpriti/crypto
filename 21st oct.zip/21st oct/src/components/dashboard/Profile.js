import * as React from 'react';
import { Box, Button, Typography, Paper, Grid, Radio, RadioGroup, FormControlLabel} from '@mui/material';
import { styled,alpha } from '@mui/material/styles';
import InputBase from '@mui/material/InputBase';
import SearchIcon from '@mui/icons-material/Search';
import SortBy from '@/src/components/dashboard/SortBy'
import ButtonGroup from '@mui/material/ButtonGroup';
import Allprofile from './Allprofile';
import { useTheme, } from '@mui/material/styles';
import StarIcon from '@mui/icons-material/Star';
import ProfileTabs from './ProfileTab';


const Search = styled('div')(({ theme }) => ({
    position: 'relative',
    borderRadius: theme.shape.borderRadius,
    backgroundColor: alpha(theme.palette.common.white, 0.15),
    '&:hover': {
      backgroundColor: alpha(theme.palette.common.white, 0.25),
    },
    marginLeft: 0,
    width: '100%',
    [theme.breakpoints.up('sm')]: {
      marginLeft: theme.spacing(1),
      width: 'auto',
      marginTop: "9px",
    },
  }));
  
  const SearchIconWrapper = styled('div')(({ theme }) => ({
    padding: theme.spacing(0, 2),
    height: '100%',
    position: 'absolute',
    pointerEvents: 'none',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  }));
  
  const StyledInputBase = styled(InputBase)(({ theme }) => ({
    color: 'inherit',
    '& .MuiInputBase-input': {
      padding: theme.spacing(1, 1, 1, 0),
      // vertical padding + font size from searchIcon
      paddingLeft: `calc(1em + ${theme.spacing(4)})`,
      transition: theme.transitions.create('width'),
      width: '100%',
      [theme.breakpoints.up('sm')]: {
        width: '12ch',
        '&:focus': {
          width: '20ch',
        },
      },
    },
  }));
  
export default function Profile() {
  const theme = useTheme();
  const tHeadColor = (theme.palette.mode == 'dark') ? "#132235" : "white";
  return (
    <Box>
    <Paper style={{ background: tHeadColor }}>
    <Grid container spacing={2} sx={{ mt:2,display:"flex", justifyContent:"end"}}>
        <Grid item xs={6} md={2}>
        <Search>
            <SearchIconWrapper>
              <SearchIcon />
            </SearchIconWrapper>
            <StyledInputBase
              placeholder="Search…"
              inputProps={{ 'aria-label': 'search' }}
            />
          </Search>
        </Grid>
        <Grid item xs={6} md={2}>
          <SortBy />
        </Grid>
      </Grid>
    <Grid container spacing={2} sx={{marginTop:"-65px"}}>
        <Grid item xs={6} md={12}>
        <ProfileTabs />
        </Grid>      
      </Grid>
    </Paper>
  </Box>
  );
}
